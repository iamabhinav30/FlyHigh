import { Injectable } from '@angular/core';
import { Router, RouterStateSnapshot } from '@angular/router';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService {

  constructor(protected router: Router,
    protected authService: AuthService) { }

  canActivate(state: RouterStateSnapshot) {
    if (sessionStorage.getItem('access-token')) {
      return true;
    }
// debugger;
    this.router.navigateByUrl['/login'];
      // { queryParams: { returnUrl: state.url } }
  }
}
