import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class TokenInterceptorService implements HttpInterceptor {

  constructor(private router: Router) {  }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    if (request.url === 'https://test.api.amadeus.com/v1/security/oauth2/token') {
      console.log
      const newHeaders = request.headers.delete('Anonymous')
      const newRequest = request.clone({ headers: newHeaders });
      return next.handle(newRequest);
    } else {
      request = request.clone({
        setHeaders: {
          Authorization: `Bearer ${sessionStorage.getItem('access_token')}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        }
      });
    }


    return next.handle(request)
      .pipe(
        tap(
          (event) => {
            if (event instanceof HttpResponse) {
              console.log('Http Request : ' + event.url + ' Response  StatusCode :' + event.status);
            }
          },
          error => {
            if (error instanceof HttpErrorResponse) {
              // if (error.status === 401) {
              console.log('Http Request : ' + error + ' Response Status Code :' + error.status);
              // this.router.navigate(['access-denied']);
              // }
            }
          }
        )
      );
  }
}