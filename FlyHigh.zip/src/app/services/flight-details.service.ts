import { map } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { interval, Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})

export class FlightDetailsService {
  constructor(private http: HttpClient) { }
 
  getLocationdetails(location?:string)
  {
    return this.http.get(`${environment.locationdetails}?subType=CITY&keyword=${location}&page%5Blimit%5D=10&page%5Boffset%5D=0&sort=analytics.travelers.score&view=FULL`)
  } 
  // getFlightDestination(origin: string, departureDate?: string, oneWay?: boolean,
  //   duration?: string, nonStop?: string, maxPrice?: any, viewBy?: string): Observable<any> {
  //   // return this.http.get()
  //   //   .pipe(
  //   //     map(result => result)
  //   //   );
  // }

  getFlightSearchList(origin, destination) {
    const sourceInterval = interval(1000);
    const apiUrl = `${environment.flightDates}?origin=${origin}&destination=${destination}&oneWay=false&nonStop=false`;
    return this.http.get(apiUrl)
      .pipe(
        map(result => result),
      );
  }
}
