import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UtilityService {

  constructor() { }

  private flightDetails = new BehaviorSubject([]);
  listFlightDetails = this.flightDetails.asObservable();

  setListFlightDetails(list) {
    this.flightDetails.next(list);
  }

  private errorMsg = new BehaviorSubject('');
  errorMsgDetail = this.errorMsg.asObservable();

  setErrorMsg(list) {
    this.errorMsg.next(list);
  }


}
