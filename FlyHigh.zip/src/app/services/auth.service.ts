import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient) { 
    let token = sessionStorage.getItem('access_token');
    if(token){

    }
  }


  login(requestPayload: any): Observable<any> {
    const apiUrl = environment.userAuth;
    let options = {
      headers: new HttpHeaders().set('Content-Type', 'application/x-www-form-urlencoded')
    };

    return this.http.post(apiUrl, requestPayload, options)
      .pipe(
        map(result => result)
      );
  }

}
