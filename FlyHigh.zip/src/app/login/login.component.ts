import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [AuthService]
})

export class LoginComponent implements OnInit {

  constructor(private auth: AuthService, private router: Router) { }

  ngOnInit(): void { }

  Login: FormGroup = new FormGroup({
    apiKey: new FormControl('AayzAp0GAZAIAYkzdmrUcMS4NU68Tj7A'),
    apiSecret: new FormControl('7pnvLPT3LEztMdAP'),
  });

  submit() {
    if (this.Login.valid) {
      const client_id = this.Login.get('apiKey').value;
      const client_secret = this.Login.get('apiSecret').value;
      let initialPayload = `grant_type=client_credentials&client_id=${client_id}&client_secret=${client_secret}`
      this.auth.login(initialPayload).subscribe(res => {
            if (res.access_token) {
          sessionStorage.setItem('access_token', res.access_token);
          setTimeout(() => {
            this.router.navigateByUrl('/search-flight');   
          }, 0);
        }
      }, error => {
        this.router.navigateByUrl('/access-denied');
      })
    }
  }

}
