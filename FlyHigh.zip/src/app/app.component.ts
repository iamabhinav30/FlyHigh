import { HttpHeaders } from '@angular/common/http';
import { Component } from '@angular/core';
import { AuthService } from './services/auth.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'flyHigh';
  initialPayload = {};
  constructor(private auth: AuthService) { }

  ngOnInit() {

    // this.initialPayload['grant_type'] = 'client_credentials';
    // this.initialPayload['client_id'] = 'AayzAp0GAZAIAYkzdmrUcMS4NU68Tj7A';
    // this.initialPayload['client_secret'] = '7pnvLPT3LEztMdAP';


    // let initialPayload = {
    //   'grant_type': 'client_credentials',
    //   'client_id': 'AayzAp0GAZAIAYkzdmrUcMS4NU68Tj7A',
    //   'client_secret': '7pnvLPT3LEztMdAP'
    // }

    // let initialPayload = `grant_type=client_credentials&client_id=AayzAp0GAZAIAYkzdmrUcMS4NU68Tj7A&client_secret=7pnvLPT3LEztMdAP`
    // this.auth.login(initialPayload).subscribe(res => {
    //   console.log(res.access_token);
    //   sessionStorage.setItem('access_token', res.access_token)
    // })

  }

}
