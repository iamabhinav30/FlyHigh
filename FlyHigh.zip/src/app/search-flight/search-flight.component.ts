import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { EMPTY, fromEvent } from 'rxjs';
import { debounceTime, distinctUntilChanged, finalize, isEmpty, map, switchMap, tap } from 'rxjs/operators';
import { FlightDetailsService } from '../services/flight-details.service';
import { UtilityService } from '../services/utility.service';
@Component({
  selector: 'app-search-flight',
  templateUrl: './search-flight.component.html',
  styleUrls: ['./search-flight.component.css']
})
export class SearchFlightComponent implements OnInit {

  @ViewChild('searchInput', { static: true }) input: ElementRef;
  @ViewChild('destinationInput', { static: true }) desInput: ElementRef;

  public  result: boolean = false;
  public noResults: boolean = false
  public noResultsOrigin:boolean = false
  public searchFlight: FormGroup;
  public originLocation: any;
  public destinations: any;
  public isLoading = false;
  public errorMsg: string;
  public noResult: string = "no result found"
  public dataLength: any

  constructor(private flightLocation: FlightDetailsService, private utility: UtilityService, private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.searchFlight = this.formBuilder.group({
      origin: ['', Validators.required],
      destination: ['', Validators.required],
      DEPARTUREdate: [new Date(), Validators.required],
      RETURNdate: [new Date(), Validators.required],
    });
  }

  displayFn(result): string | undefined {
    return result ? result.label : undefined
  }

  ngAfterViewInit() {
    fromEvent<any>(this.input.nativeElement, 'keyup')
      .pipe(
        map(event => event.target.value),
        debounceTime(300),
        distinctUntilChanged(),
        switchMap(search => (search) ? this.flightLocation.getLocationdetails(search) : EMPTY
        )
      ).subscribe(response => {
        console.log(response)
        if (response) {
          if (response['data'].length > 0) {
            this.originLocation = response['data'];
            console.log("dsllhdshdsf", this.originLocation)
          }
          else {
            this.noResultsOrigin = true
          }
        }
      });

    fromEvent<any>(this.desInput.nativeElement, 'keyup')
      .pipe(
        map(event => event.target.value),
        debounceTime(300),
        distinctUntilChanged(),
        switchMap(search => (search) ? this.flightLocation.getLocationdetails(search) : EMPTY
        )
      ).subscribe(response => {
        if (response) {
          if (response['data'].length > 0) {
            this.destinations = response['data'];
            console.log("dsllhdshdsf", this.destinations, response['data'].length)
          }
          else {
            this.noResults = true
          }
        }
      });
  }

  submit() {
    if (this.searchFlight.valid) {
      const origins = this.searchFlight.get('origin').value;
      const destinations = this.searchFlight.get('destination').value;
      console.log("origin", origins, "destination", destinations)
      // this.flightLocation.getLocationdetails(origins).subscribe((response)=>{
      //   console.log("fligh location", response)

      // })

      this.flightLocation.getFlightSearchList(origins, destinations).subscribe(res => {
        this.result = true;
        // console.log(res['data']);
        this.utility.setListFlightDetails(res['data']);
        // res['data'];
      }, error=>{
        console.log('ERROR ERROR ERROR');
        this.utility.setErrorMsg('No Record found');
        this.result = true;
      })
    }
  }
}
