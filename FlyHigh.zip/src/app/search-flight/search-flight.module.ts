import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SearchFlightRoutingModule } from './search-flight-routing.module';
import { SearchFlightComponent } from './search-flight.component';
import { DemoMaterialModule } from '../material.module';
import { HeaderComponent } from '../common/header/header.component';
import { ReactiveFormsModule } from '@angular/forms';
import { FlightDetailsComponent } from './flight-details/flight-details.component';


@NgModule({
  declarations: [SearchFlightComponent,HeaderComponent, FlightDetailsComponent],
  imports: [
    CommonModule,
    SearchFlightRoutingModule,
    DemoMaterialModule,
    ReactiveFormsModule
  ]
})
export class SearchFlightModule { }
