import { UtilityService } from './../../services/utility.service';
import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-flight-details',
  templateUrl: './flight-details.component.html',
  styleUrls: ['./flight-details.component.css']
})
export class FlightDetailsComponent implements OnInit {

  public displayedColumns: string[] = ['origin', 'departureDate', 'destination', 'returnDate'];
  public dataList: any;
  public dataSource;
  public errorMsg;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(private utility: UtilityService) { }

  ngOnInit() {

    this.utility.listFlightDetails.subscribe(res => {
      if (res !== []) {
        console.log(res);
        this.dataSource = new MatTableDataSource<any>(res);
     }
    })

    this.utility.errorMsgDetail.subscribe(res => {
      if (res) {
        console.log(res);
        this.errorMsg= res;
     }
    })
  }

 ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }
}

